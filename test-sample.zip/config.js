const path = require('path');

module.exports = {
  port: 3000,
  database: {
    host: 'localhost',
    port: 5432
  },
  paths: {
    src: path.join(__dirname, 'src'),
    dist: path.join(__dirname, 'dist')
  }
};
