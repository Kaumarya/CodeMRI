const fs = require('fs');
const path = require('path');

function formatDate(date) {
  return date.toISOString();
}

function readFile(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

module.exports = {
  formatDate,
  readFile
};
